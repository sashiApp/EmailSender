package com.sashi.mailSender.processor;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import com.sashi.mailSender.exceptions.ApplicationException;


/*
 * Utility to send bulk email to recipients. 
 * Parse file to read email recipients, send email.
 * 
 */
public class EmailSender {
	
	/*
	 * Read csv file and send email.
	 * 
	 */
	public void sendBulkEmailFromFile(String receiversFile) {
		
		try {
			//Read file
			Stream<String> stream = Files.lines(Paths.get(receiversFile));
			ExecutorService emailExecutor = Executors.newCachedThreadPool();
			
			//Send email to each recipient
			stream.filter(line-> line != null && line.length() > 1).forEach(line ->
			{
				try {
					String[] details = line.replaceAll("\"", "").split(";");
					String emailId = details[0];
					String firstName = details[1];
					String lastName = details[2];
					
					if(emailId != null && firstName != null && lastName != null) {
						        emailExecutor.execute(new Runnable() {
						            @Override
						            public void run() {
						                try {
						                	System.out.println("Sending email to:"+emailId);
						                	try {
						            			
												//Sleep for 
						            			Thread.sleep(500);
						            		} catch (InterruptedException e) {
						            			// TODO Auto-generated catch block
						            			e.printStackTrace();						            		}
						                	sendEmail(emailId,firstName,lastName);
						                } catch (Exception e) {
						                    e.printStackTrace();
						                }
						            }
						        });
						 
					}else {
						throw new ApplicationException("EmailSender: Email not sent invalid receipent details.");
					}
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
			);
			stream.close();
			emailExecutor.shutdown(); 
		} catch (Exception e) {
			e.printStackTrace();
		}
	
	}
	
	/*
	 * Send email to the provided email Id
	 * Note: currently mocked.Todo: Implement.
	 */
	public void sendEmail(String emailId,String firstName,String lastName) {
		System.out.println("Email sent to:"+emailId);
	}
}
