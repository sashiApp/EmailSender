package com.sashi.mailSender;


import java.util.Scanner;

import com.sashi.mailSender.exceptions.ApplicationException;
import com.sashi.mailSender.processor.EmailSender;
import com.sashi.mailSender.util.Validator;

/*
 * Main class to run the Email sender.
 * 
 */
public class Main {

	/*
	 * Main  method to run Email sender. 
	 * Provide valid CSV file path to send email to recipients.
	 * 
	 */
	public static void main(String[] args) {
		try{
				Scanner in = new Scanner(System.in);
				System.out.println("Enter the email recipients file path:");
				String recipientsFile = in.nextLine();
				if(!Validator.isValidFilePath(recipientsFile)){
					throw new ApplicationException("Main: Invaid file name");
				}
				//Send file name to parse and send email.
				EmailSender emaiSender = new EmailSender();
				emaiSender.sendBulkEmailFromFile(recipientsFile);
				
		}catch(ApplicationException ae){
			System.out.println("Application Exception:"+ae);
		}catch(Exception e){
			System.out.println("Unknown Exception:"+e);
		}
	}

}
